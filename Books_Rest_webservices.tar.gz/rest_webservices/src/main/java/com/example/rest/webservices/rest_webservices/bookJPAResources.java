package com.example.rest.webservices.rest_webservices;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.sun.el.stream.Optional;

@RestController
public class bookJPAResources {

	@Autowired
	private userDaoServices services;
	@Autowired
	private bookRepository bookrepository;
	@GetMapping("/jpa/books")
	public List<books> retrieveAllUsers(){
		return bookrepository.findAll();
	}
	
	@GetMapping("/jpa/books/{id}")
	public java.util.Optional<books> retrieveUserID(@PathVariable int id) {
		//return services.findOne(id);
	java.util.Optional<books> bookinfo= bookrepository.findById(id);
	return bookinfo;
	
	}
	
	
	@PostMapping("/jpa/books/updateAvailability/{id}/{incrementCount}")
	public books updateAvailablity(@PathVariable int id,@PathVariable("incrementCount") int incrementCount){
		//books b1 = null;
	java.util.Optional<books> bookD=bookrepository.findById(id);
	if(bookD.isPresent())
		System.out.println("check if book id exist"+bookD.get().getAvailable_copies()+"  increment value" +incrementCount);
	books b1=bookD.get();	
	System.out.println("am checking with bookDddd"+bookD.get().getAvailable_copies());
	b1.setAvailable_copies(b1.getAvailable_copies()+incrementCount);
	System.out.println("what is the value "+b1.getAvailable_copies());
	System.out.println("this is id value"+id+"  this is increment"+incrementCount);
	books b3=bookrepository.save(b1);
	return b3;
	}
	
	
}
