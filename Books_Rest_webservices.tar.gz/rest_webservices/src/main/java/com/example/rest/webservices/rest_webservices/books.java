package com.example.rest.webservices.rest_webservices;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class books {
	@Id
	private Integer bookId;
	private String book_name;
	private String Author;
	private Integer Available_copies;
	private Integer Total_copies;
	
	public books() {
		
	}
	public books(Integer bookId, String book_name, String author, Integer available_copies, Integer total_copies) {
		super();
		this.bookId = bookId;
		this.book_name = book_name;
		Author = author;
		Available_copies = available_copies;
		Total_copies = total_copies;
	}
	@Override
	public String toString() {
		return "books [bookId=" + bookId + ", book_name=" + book_name + ", Author=" + Author + ", Available_copies="
				+ Available_copies + ", Total_copies=" + Total_copies + "]";
	}

	public Integer getBookId() {
		return bookId;
	}
	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	public Integer getAvailable_copies() {
		return Available_copies;
	}
	public void setAvailable_copies(Integer available_copies) {
		Available_copies = available_copies;
	}
	public Integer getTotal_copies() {
		return Total_copies;
	}
	public void setTotal_copies(Integer total_copies) {
		Total_copies = total_copies;
	}
	

}
