package com.example.rest.webservices.rest_webservices;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class userDaoServices {
private static int userCount =3;
private static List<user> users= new ArrayList<>();	

static {
	users.add(new user(1, "vikas"));
	users.add(new user(2, "vikas2"));
	users.add(new user(3, "vikas3"));
	
}


public List<user> findAll(){
	return users;
}


public user save(user user) {
	if(user.getId()==null) {
		user.setId(++userCount);
		
	}
	users.add(user);
	return user;
}

public user findOne(int id) {
	System.out.println("am in find one method");
	for(user user:users) {
		System.out.println("after for loop");
		if (user.getId()==id)
			System.out.println("am in if method with" +id +"this is the value from user" +user);
			return user;
	}
	return null;
	
}

}
