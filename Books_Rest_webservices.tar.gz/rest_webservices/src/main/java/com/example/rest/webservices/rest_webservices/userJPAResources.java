package com.example.rest.webservices.rest_webservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sun.el.stream.Optional;

@RestController
public class userJPAResources {

	@Autowired
	private userDaoServices services;
	@Autowired
	private userRepository userrepository;
	@GetMapping("/jpa/users")
	public List<user> retrieveAllUsers(){
		return userrepository.findAll();
	}
	
	@GetMapping("/jpa/users/{id}")
	public java.util.Optional<user> retrieveUserID(@PathVariable int id) {
		//return services.findOne(id);
	java.util.Optional<user> user= userrepository.findById(id);
	return user;
	
	}
}
