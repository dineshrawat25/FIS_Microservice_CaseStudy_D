package com.example.rest.webservices.rest_webservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class userResources {

	@Autowired
	private userDaoServices services;
	@GetMapping("/users")
	public List<user> retrieveAllUsers(){
		return services.findAll();
	}
	
	@GetMapping("/users/{id}")
	public user retrieveUserID(@PathVariable int id) {
		return services.findOne(id);
	}
}
