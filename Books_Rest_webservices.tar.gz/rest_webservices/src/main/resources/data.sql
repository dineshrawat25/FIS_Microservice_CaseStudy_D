INSERT INTO USER values(1,'shiva');
INSERT INTO USER values(2,'pandey');
INSERT INTO USER values(3,'lata');
INSERT INTO USER values(4,'vikas');


INSERT INTO BOOKS values(1212,'History of Amazonvalley',0,2,'ROSS Suarez');

INSERT INTO BOOKS values(4232,'Language fundamentals',5,5,'HS Parkmay');