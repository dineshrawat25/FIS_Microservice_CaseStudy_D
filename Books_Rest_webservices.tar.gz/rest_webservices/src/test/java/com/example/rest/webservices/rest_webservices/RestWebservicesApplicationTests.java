package com.example.rest.webservices.rest_webservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
