package com.fis.casestudy.books;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {

	@Id
	private String bookId;
	private String name;
	private String author;
	public int getAvailable_copies() {
		return available_copies;
	}

	public void setAvailable_copies(int available_copies) {
		this.available_copies = available_copies;
	}

	public int getTotal_copies() {
		return total_copies;
	}

	public void setTotal_copies(int total_copies) {
		this.total_copies = total_copies;
	}

	private int available_copies;
	private int total_copies;


	public Book() {
	}

	public Book(String bookId, String name, String author, int available_copies, int total_copies) {
		this.bookId = bookId;
		this.name = name;
		this.author = author;
		this.available_copies = available_copies;
		this.total_copies = total_copies;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getBookId() {
		return bookId;
	}

	public String getName() {
		return name;
	}

	public String getAuthor() {
		return author;
	}


	@Override
	public boolean equals(Object o) {

		if (this == o)
			return true;
		if (!(o instanceof Book))
			return false;
		Book book = (Book) o;
		return Objects.equals(this.bookId, book.bookId) && Objects.equals(this.name, book.name);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.bookId, this.name);
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", name=" + name + ", author=" + author + ", available_copies=" + available_copies
				+ ", total_copies=" + total_copies + "]";
	}
}
