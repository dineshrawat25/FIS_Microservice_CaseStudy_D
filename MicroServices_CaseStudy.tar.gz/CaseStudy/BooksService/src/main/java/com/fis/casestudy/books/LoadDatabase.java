package com.fis.casestudy.books;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadDatabase {
	private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

	@Bean
	CommandLineRunner initDatabase(BookRepository repository) {

		return args -> {
			log.info("Preloading "
					+ repository.save(new Book("B1212", "History of Amazon Valley", "Ross Saurez", 2, 5)));
			log.info("Preloading "
					+ repository.save(new Book("B4232", "Language of Fundamentals", "H S Parkmay", 5, 5)));
		};
	}
}
