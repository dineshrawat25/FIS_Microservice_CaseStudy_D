package com.fis.casestudy.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServiceTests {

	@Test
	void contextLoads() {
	}

}
