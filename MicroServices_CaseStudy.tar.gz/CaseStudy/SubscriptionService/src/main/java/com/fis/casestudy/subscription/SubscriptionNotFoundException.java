package com.fis.casestudy.subscription;

public class SubscriptionNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public  SubscriptionNotFoundException(String id) {
	    super("Could not find Subscription " + id);
	  } 

}
